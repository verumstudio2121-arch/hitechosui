package com.hitech.tvos

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.ViewTreeObserver
import android.widget.Toast
import androidx.leanback.widget.VerticalGridView
import com.hitech.tvos.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var b: ActivityMainBinding
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private val dockAdapter = AppAdapter(false) { open(it) }
    private val gridAdapter = AppAdapter(true) { open(it) }
    private var library: List<AppEntry> = emptyList()
    private var scrolled = false
    private var lastWeatherAt = 0L
    private var weatherText = "${Config.CITY} · --°"
    private val dateFmt = SimpleDateFormat("EEEE d MMMM", Locale.getDefault())

    // Registered only while the launcher is visible -> zero background cost.
    private val tickReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = refreshTimeContext()
    }
    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = loadApps()
    }
    private val netReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = refreshWifi()
    }
    private val focusListener = ViewTreeObserver.OnGlobalFocusChangeListener { _, newFocus ->
        if (newFocus != null) setScrolled(isInside(newFocus, b.grid) || newFocus === b.pillLibrary)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // The layout is designed on a 960 x 540 dp canvas; pin density so it looks identical on any TV.
        val dm = resources.displayMetrics
        val d = dm.widthPixels / 960f
        dm.density = d
        dm.scaledDensity = d
        dm.densityDpi = (160 * d).toInt()

        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.dock.setHasFixedSize(true)
        b.dock.itemAnimator = null
        b.dock.setItemSpacing((10 * d).toInt())
        b.dock.adapter = dockAdapter

        b.grid.itemAnimator = null
        b.grid.setNumColumns(6)
        b.grid.setColumnWidth((124 * d).toInt())
        b.grid.setHorizontalSpacing((10 * d).toInt())
        b.grid.setVerticalSpacing(0)
        b.grid.adapter = gridAdapter

        for (pill in listOf(b.pillInputs, b.pillWifi, b.pillSettings, b.pillLibrary)) {
            pill.setOnFocusChangeListener { v, focused ->
                val s = if (focused) 1.07f else 1f
                v.animate().scaleX(s).scaleY(s).setDuration(120).start()
            }
        }
        b.pillInputs.setOnClickListener { showInputs() }
        b.pillWifi.setOnClickListener { launch(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        b.pillSettings.setOnClickListener { launch(Intent(Settings.ACTION_SETTINGS)) }
        b.pillLibrary.setOnClickListener { showLibrary() }

        b.rootLayout.viewTreeObserver.addOnGlobalFocusChangeListener(focusListener)

        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 1)

        loadApps()
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(tickReceiver, IntentFilter(Intent.ACTION_TIME_TICK).apply {
            addAction(Intent.ACTION_TIMEZONE_CHANGED); addAction(Intent.ACTION_TIME_CHANGED)
        })
        registerReceiver(pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
        })
        registerReceiver(netReceiver, IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION))

        refreshTimeContext()
        refreshStats()
        refreshWifi()
        refreshWeatherIfStale()
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(tickReceiver)
        unregisterReceiver(pkgReceiver)
        unregisterReceiver(netReceiver)
    }

    override fun onDestroy() { super.onDestroy(); io.shutdownNow() }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() = goHome()

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.action == Intent.ACTION_MAIN) goHome()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r); refreshWifi()
    }

    private fun goHome() {
        b.grid.scrollToPosition(0)
        b.dock.scrollToPosition(0)
        b.dock.requestFocus()
    }

    // ---------- scroll state: clock fades out, dock + grid slide up ----------

    private fun isInside(v: View, parent: View): Boolean {
        var p: View? = v
        while (p != null) { if (p === parent) return true; p = p.parent as? View }
        return false
    }

    private fun setScrolled(s: Boolean) {
        if (s == scrolled) return
        scrolled = s
        val shift = 233f * resources.displayMetrics.density
        b.apps.animate().translationY(if (s) -shift else 0f).setDuration(260).start()
        b.clockBlock.animate().alpha(if (s) 0f else 1f).setDuration(220).start()
        b.pillLibrary.visibility = if (s) View.VISIBLE else View.INVISIBLE
    }

    // ---------- UI refresh ----------

    private fun refreshTimeContext() {
        val cal = Calendar.getInstance()
        val h = cal.get(Calendar.HOUR_OF_DAY)
        val greeting = when {
            h in 5..11 -> "Good morning"
            h in 12..16 -> "Good afternoon"
            h in 17..20 -> "Good evening"
            else -> "Movie time"
        }
        val popcorn = if (greeting == "Movie time") " \uD83C\uDF7F" else ""
        b.greeting.text = "$greeting, ${Config.OWNER_NAMES}$popcorn"
        b.date.text = dateFmt.format(cal.time)
        b.weather.text = weatherText
        b.scene.setHour(h)
        b.clock.setTextColor(b.scene.scene.clockColor)
        b.dayNight.setImageResource(if (h in 6..17) R.drawable.ic_sun else R.drawable.ic_moon)
    }

    private fun refreshStats() { b.hwStats.text = SystemStats.summary(this) }

    private fun refreshWeatherIfStale() {
        if (System.currentTimeMillis() - lastWeatherAt < Config.WEATHER_REFRESH_MS) return
        lastWeatherAt = System.currentTimeMillis()
        io.execute {
            val w = WeatherRepository.fetch()
            ui.post { if (w != null) { weatherText = w; b.weather.text = w } else lastWeatherAt = 0L }
        }
    }

    @Suppress("DEPRECATION")
    private fun refreshWifi() {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val type = cm.activeNetworkInfo?.takeIf { it.isConnected }?.type
        b.wifiText.text = when (type) {
            ConnectivityManager.TYPE_WIFI -> {
                val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
                val ssid = wm.connectionInfo?.ssid?.trim('"')
                if (ssid.isNullOrBlank() || ssid == "<unknown ssid>") getString(R.string.wifi) else ssid
            }
            ConnectivityManager.TYPE_ETHERNET -> "Ethernet"
            null -> "Offline"
            else -> getString(R.string.wifi)
        }
    }

    // ---------- Apps ----------

    private fun loadApps() {
        io.execute {
            val cat = AppRepository.load(this)
            ui.post {
                dockAdapter.submit(cat.pinned)
                gridAdapter.submit(cat.grid)
                library = cat.all
                if (!scrolled && currentFocus == null) b.dock.post { b.dock.requestFocus() }
            }
        }
    }

    private fun open(e: AppEntry) = launch(e.launchIntent)

    private fun launch(intent: Intent) {
        try { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(this, "Unable to open", Toast.LENGTH_SHORT).show() }
    }

    private fun showLibrary() {
        val dlg = Dialog(this, android.R.style.Theme_Material_NoActionBar_Fullscreen)
        val v = layoutInflater.inflate(R.layout.dialog_library, null)
        val g = v.findViewById<VerticalGridView>(R.id.libGrid)
        val d = resources.displayMetrics.density
        val adapter = AppAdapter(true) { dlg.dismiss(); open(it) }
        g.setNumColumns(6)
        g.setColumnWidth((124 * d).toInt())
        g.setHorizontalSpacing((10 * d).toInt())
        g.setVerticalSpacing(0)
        g.adapter = adapter
        adapter.submit(library)
        dlg.setContentView(v)
        dlg.show()
    }

    // ---------- Inputs ----------

    private fun showInputs() {
        val tim = getSystemService(Context.TV_INPUT_SERVICE) as TvInputManager
        val inputs: List<TvInputInfo> = tim.tvInputList.filter { it.isPassthroughInput }
        if (inputs.isEmpty()) { launch(Intent(Settings.ACTION_SETTINGS)); return }
        val labels = inputs.map { (it.loadCustomLabel(this) ?: it.loadLabel(this)).toString() }.toTypedArray()
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(R.string.inputs)
            .setItems(labels) { _, which ->
                launch(Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(inputs[which].id)))
            }.show()
    }
}
