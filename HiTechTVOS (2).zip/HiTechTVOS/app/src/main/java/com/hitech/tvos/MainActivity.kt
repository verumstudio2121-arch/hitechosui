package com.hitech.tvos

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.leanback.widget.BaseGridView
import com.hitech.tvos.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var b: ActivityMainBinding
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private val adapter = AppAdapter { launch(it.launchIntent) }
    private var lastWeatherAt = 0L
    private var weatherText = "${Config.CITY} · --°"
    private val dateFmt = SimpleDateFormat("EEEE d MMMM", Locale.getDefault())

    // Registered only while the launcher is visible -> zero background cost.
    private val tickReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = refreshTimeContext()
    }
    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = loadApps()
    }
    private val netReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = refreshWifi()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.dock.setHasFixedSize(true)
        b.dock.itemAnimator = null
        b.dock.adapter = adapter
        b.dock.windowAlignment = BaseGridView.WINDOW_ALIGN_NO_EDGE
        b.dock.windowAlignmentOffsetPercent = 0f

        b.pillInputs.setOnClickListener { showInputs() }
        b.pillWifi.setOnClickListener { launch(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        b.pillSettings.setOnClickListener { launch(Intent(Settings.ACTION_SETTINGS)) }

        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 1)

        loadApps()
        b.dock.requestFocus()
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(tickReceiver, IntentFilter(Intent.ACTION_TIME_TICK).apply {
            addAction(Intent.ACTION_TIMEZONE_CHANGED); addAction(Intent.ACTION_TIME_CHANGED)
        })
        registerReceiver(pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
        })
        registerReceiver(netReceiver, IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION))

        refreshTimeContext()
        refreshStats()
        refreshWifi()
        refreshWeatherIfStale()
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(tickReceiver)
        unregisterReceiver(pkgReceiver)
        unregisterReceiver(netReceiver)
    }

    override fun onDestroy() { super.onDestroy(); io.shutdownNow() }

    // A launcher must never exit on Back.
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() { b.dock.scrollToPosition(0); b.dock.requestFocus() }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.action == Intent.ACTION_MAIN) { b.dock.scrollToPosition(0); b.dock.requestFocus() }
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r); refreshWifi()
    }

    // ---------- UI refresh ----------

    private fun refreshTimeContext() {
        val cal = Calendar.getInstance()
        val h = cal.get(Calendar.HOUR_OF_DAY)
        val greeting = when {
            h < 5 -> "Late night"
            h < 12 -> "Good morning"
            h < 17 -> "Good afternoon"
            h < 21 -> "Good evening"
            else -> "Movie time"
        }
        b.greeting.text = "$greeting, ${Config.OWNER_NAMES} \uD83C\uDF7F"
        b.date.text = dateFmt.format(cal.time)
        b.dayNight.setImageResource(if (h in 6..17) R.drawable.ic_sun else R.drawable.ic_moon)
        b.weather.text = weatherText
    }

    private fun refreshStats() { b.hwStats.text = SystemStats.summary(this) }

    private fun refreshWeatherIfStale() {
        if (System.currentTimeMillis() - lastWeatherAt < Config.WEATHER_REFRESH_MS) return
        lastWeatherAt = System.currentTimeMillis()
        io.execute {
            val w = WeatherRepository.fetch()
            ui.post { if (w != null) { weatherText = w; b.weather.text = w } else lastWeatherAt = 0L }
        }
    }

    @Suppress("DEPRECATION")
    private fun refreshWifi() {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val type = cm.activeNetworkInfo?.takeIf { it.isConnected }?.type
        b.wifiText.text = when (type) {
            ConnectivityManager.TYPE_WIFI -> {
                val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
                val ssid = wm.connectionInfo?.ssid?.trim('"')
                if (ssid.isNullOrBlank() || ssid == "<unknown ssid>") getString(R.string.wifi) else ssid
            }
            ConnectivityManager.TYPE_ETHERNET -> "Ethernet"
            null -> "Offline"
            else -> getString(R.string.wifi)
        }
    }

    // ---------- Apps ----------

    private fun loadApps() {
        io.execute {
            val apps = AppRepository.load(this)
            ui.post { adapter.submit(apps) }
        }
    }

    private fun launch(intent: Intent) {
        try { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(this, "Unable to open", Toast.LENGTH_SHORT).show() }
    }

    // ---------- Inputs ----------

    /** Lists HDMI/AV passthrough inputs via TvInputManager and switches to the chosen one. */
    private fun showInputs() {
        val tim = getSystemService(Context.TV_INPUT_SERVICE) as TvInputManager
        val inputs: List<TvInputInfo> = tim.tvInputList.filter { it.isPassthroughInput }
        if (inputs.isEmpty()) { launch(Intent(Settings.ACTION_SETTINGS)); return }

        val labels = inputs.map { (it.loadCustomLabel(this) ?: it.loadLabel(this)).toString() }.toTypedArray()
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(R.string.inputs)
            .setItems(labels) { _, which ->
                launch(Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(inputs[which].id)))
            }.show()
    }
}
