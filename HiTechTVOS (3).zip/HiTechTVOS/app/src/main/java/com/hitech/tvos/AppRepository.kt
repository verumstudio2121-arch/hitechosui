package com.hitech.tvos

import android.content.Context
import android.content.Intent

class Catalog(val pinned: List<AppEntry>, val grid: List<AppEntry>, val all: List<AppEntry>)

/** Blocking – call from a background thread only. */
object AppRepository {

    private val PRIORITY = listOf(
        listOf("com.google.android.youtube.tv", "com.google.android.youtube"),
        listOf("com.netflix.ninja", "com.netflix.mediaclient"),
        listOf("in.startv.hotstar.dplus.tv", "in.startv.hotstar.dplus", "in.startv.hotstar"),
        listOf("com.amazon.amazonvideo.livingroom", "com.amazon.avod"),
        listOf("com.sonyliv"),
        listOf("com.google.android.youtube.tvmusic", "com.google.android.apps.youtube.music")
    )
    private const val DOCK_SIZE = 6

    private fun rank(pkg: String): Int {
        val i = PRIORITY.indexOfFirst { pkg in it }
        return if (i == -1) Int.MAX_VALUE else i
    }

    fun load(ctx: Context): Catalog {
        val pm = ctx.packageManager
        val seen = LinkedHashMap<String, AppEntry>()
        val tvPackages = HashSet<String>()

        for (category in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == ctx.packageName) continue
                if (category == Intent.CATEGORY_LEANBACK_LAUNCHER) tvPackages.add(pkg)
                if (seen.containsKey(pkg)) continue
                val launch = pm.getLeanbackLaunchIntentForPackage(pkg)
                    ?: pm.getLaunchIntentForPackage(pkg) ?: continue
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                val banner = ri.activityInfo.loadBanner(pm)
                seen[pkg] = AppEntry(
                    packageName = pkg,
                    label = ri.loadLabel(pm).toString(),
                    banner = banner ?: ri.loadIcon(pm),
                    hasBanner = banner != null,
                    launchIntent = launch
                )
            }
        }

        val all = seen.values.sortedWith(compareBy<AppEntry>({ rank(it.packageName) }, { it.label.lowercase() }))
        val tv = all.filter { it.packageName in tvPackages || rank(it.packageName) != Int.MAX_VALUE }

        val pinned = ArrayList<AppEntry>(tv.filter { rank(it.packageName) != Int.MAX_VALUE }.take(DOCK_SIZE))
        for (e in tv) { if (pinned.size >= DOCK_SIZE) break; if (e !in pinned) pinned.add(e) }
        val grid = tv.filter { it !in pinned }
        return Catalog(pinned, grid, all)
    }
}
