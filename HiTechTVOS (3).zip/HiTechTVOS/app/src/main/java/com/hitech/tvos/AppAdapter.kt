package com.hitech.tvos

import android.graphics.Outline
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.hitech.tvos.databinding.ItemAppBinding

/** labelBelow = true shows the app name under a tile while it has focus (grid / library). */
class AppAdapter(
    private val labelBelow: Boolean,
    private val onLaunch: (AppEntry) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppEntry> = emptyList()

    init { setHasStableIds(true) }

    class VH(val b: ItemAppBinding) : RecyclerView.ViewHolder(b.root)

    fun submit(new: List<AppEntry>) {
        val old = items
        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = old.size
            override fun getNewListSize() = new.size
            override fun areItemsTheSame(o: Int, n: Int) = old[o].packageName == new[n].packageName
            override fun areContentsTheSame(o: Int, n: Int) = old[o].label == new[n].label
        })
        items = new
        diff.dispatchUpdatesTo(this)
    }

    override fun getItemId(position: Int) = items[position].packageName.hashCode().toLong()
    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        val vh = VH(b)
        val radius = 10f * parent.resources.displayMetrics.density

        b.tile.clipToOutline = true
        b.tile.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
        b.label.visibility = if (labelBelow) View.INVISIBLE else View.GONE

        b.itemRoot.setOnClickListener { items.getOrNull(vh.adapterPosition)?.let(onLaunch) }
        b.itemRoot.onFocusChangeListener = View.OnFocusChangeListener { v, focused ->
            val s = if (focused) 1.1f else 1f
            b.tile.animate().cancel()
            b.tile.animate().scaleX(s).scaleY(s).setDuration(140)
                .setInterpolator(DecelerateInterpolator()).start()
            v.translationZ = if (focused) 10f else 0f
            if (labelBelow) b.label.visibility = if (focused) View.VISIBLE else View.INVISIBLE
        }
        return vh
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val e = items[position]
        val d = h.b.root.resources.displayMetrics.density
        h.b.banner.setImageDrawable(e.banner)
        h.b.label.text = e.label
        if (e.hasBanner) {
            h.b.banner.scaleType = ImageView.ScaleType.CENTER_CROP
            h.b.banner.setPadding(0, 0, 0, 0)
        } else {
            val p = (14 * d).toInt()
            h.b.banner.scaleType = ImageView.ScaleType.FIT_CENTER
            h.b.banner.setPadding(p, p, p, p)
        }
    }
}
