package com.hitech.tvos

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** One-shot HTTPS call (Open-Meteo, no API key). Run on a background thread. */
object WeatherRepository {

    fun fetch(): String? = try {
        val url = URL("https://api.open-meteo.com/v1/forecast" +
            "?latitude=${Config.LATITUDE}&longitude=${Config.LONGITUDE}" +
            "&current=temperature_2m,weather_code")
        val c = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 6000; readTimeout = 6000
        }
        val body = c.inputStream.bufferedReader().use { it.readText() }
        c.disconnect()
        val cur = JSONObject(body).getJSONObject("current")
        val temp = Math.round(cur.getDouble("temperature_2m")).toInt()
        "${Config.CITY} · $temp° · ${describe(cur.getInt("weather_code"))}"
    } catch (_: Exception) { null }

    private fun describe(code: Int) = when (code) {
        0 -> "Clear"
        1, 2 -> "Partly cloudy"
        3 -> "Cloudy"
        45, 48 -> "Fog"
        in 51..57 -> "Drizzle"
        in 61..67, in 80..82 -> "Rain"
        in 71..77 -> "Snow"
        in 95..99 -> "Thunderstorm"
        else -> "—"
    }
}
