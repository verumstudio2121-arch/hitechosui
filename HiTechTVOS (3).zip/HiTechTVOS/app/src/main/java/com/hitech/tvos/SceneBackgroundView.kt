package com.hitech.tvos

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import java.util.Calendar
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

/**
 * Time-of-day scenery: sky gradient + layered mountain ridges (+ stars at night).
 * Drawn once into a half-resolution bitmap and re-drawn only when the time bucket changes,
 * so there is no per-frame cost and no blur shader.
 */
class SceneBackgroundView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    class Scene(val top: Int, val bottom: Int, val mountain: Int, val stars: Boolean, val clockColor: Int)

    companion object {
        val NIGHT = Scene(0xFF0A1B7A.toInt(), 0xFF1D52D6.toInt(), 0xFF050F4A.toInt(), true, 0xFF7FF3E6.toInt())
        val DAWN = Scene(0xFFFFB98F.toInt(), 0xFFFBE0CF.toInt(), 0xFFC4755A.toInt(), false, 0xFFFFFFFF.toInt())
        val DAY = Scene(0xFF4DA6EE.toInt(), 0xFFBCE4FB.toInt(), 0xFF2F72B5.toInt(), false, 0xFFFFFFFF.toInt())
        val EVENING = Scene(0xFFE3A9B6.toInt(), 0xFFF6D6D0.toInt(), 0xFFB5668A.toInt(), false, 0xFFFFFFFF.toInt())

        fun sceneFor(hour: Int): Scene = when (hour) {
            in 5..7 -> DAWN
            in 8..16 -> DAY
            in 17..20 -> EVENING
            else -> NIGHT
        }
    }

    var scene: Scene = sceneFor(Calendar.getInstance().get(Calendar.HOUR_OF_DAY))
        private set

    private var bitmap: Bitmap? = null
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dst = Rect()

    fun setHour(hour: Int) {
        val s = sceneFor(hour)
        if (s !== scene) { scene = s; rebuild() }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuild()
    }

    private fun rebuild() {
        if (width == 0 || height == 0) return
        val bw = width / 2
        val bh = height / 2
        val bm = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bm)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        p.shader = LinearGradient(0f, 0f, 0f, bh.toFloat(), scene.top, scene.bottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), p)
        p.shader = null

        if (scene.stars) {
            val r = Random(42)
            repeat(90) {
                p.color = Color.argb(90 + r.nextInt(165), 255, 255, 255)
                c.drawCircle(r.nextFloat() * bw, r.nextFloat() * bh * 0.65f, 0.7f + r.nextFloat() * 1.1f, p)
            }
        }

        val baseY = floatArrayOf(0.50f, 0.60f, 0.70f, 0.80f)
        val alpha = floatArrayOf(0.10f, 0.14f, 0.19f, 0.26f)
        val rnd = Random(11)
        val path = Path()
        for (i in baseY.indices) {
            val f1 = (2 * PI * (1.2 + i * 0.45) / bw).toFloat()
            val f2 = (2 * PI * (3.1 + i * 0.7) / bw).toFloat()
            val p1 = rnd.nextFloat() * 6.28f
            val p2 = rnd.nextFloat() * 6.28f
            val amp = bh * 0.055f
            path.reset()
            path.moveTo(0f, bh.toFloat())
            var x = 0
            while (x <= bw) {
                val y = bh * baseY[i] + amp * (0.65f * sin(x * f1 + p1) + 0.35f * sin(x * f2 + p2))
                path.lineTo(x.toFloat(), y)
                x += 4
            }
            path.lineTo(bw.toFloat(), bh.toFloat())
            path.close()
            p.color = Color.argb(
                (alpha[i] * 255).toInt(),
                Color.red(scene.mountain), Color.green(scene.mountain), Color.blue(scene.mountain)
            )
            c.drawPath(path, p)
        }

        bitmap?.recycle()
        bitmap = bm
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val bm = bitmap ?: return
        dst.set(0, 0, width, height)
        canvas.drawBitmap(bm, null, dst, paint)
    }
}
