package com.hitech.tvos

import android.content.Intent
import android.graphics.drawable.Drawable

data class AppEntry(
    val packageName: String,
    val label: String,
    val banner: Drawable,
    val hasBanner: Boolean,
    val launchIntent: Intent
)
